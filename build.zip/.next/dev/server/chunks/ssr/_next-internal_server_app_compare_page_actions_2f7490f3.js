module.exports = [
"[project]/.next-internal/server/app/compare/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_compare_page_actions_2f7490f3.js.map