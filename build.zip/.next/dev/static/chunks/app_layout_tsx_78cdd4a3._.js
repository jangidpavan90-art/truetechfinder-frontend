(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_globals_71f961d1.css",
  "static/chunks/node_modules_66ae3532._.js",
  "static/chunks/_9bb12c2f._.js"
],
    source: "dynamic"
});
