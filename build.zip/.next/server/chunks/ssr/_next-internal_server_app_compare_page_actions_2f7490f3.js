module.exports=[66644,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_compare_page_actions_2f7490f3.js.map