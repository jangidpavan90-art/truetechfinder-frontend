module.exports=[70841,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_scan_page_actions_6241df5a.js.map